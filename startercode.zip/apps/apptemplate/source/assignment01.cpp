//
// File:   assignment1.cpp
// Author: <PUT YOUR NAME HERE>
// Purpose:
// Illustrate some of the bad thins that can happen with
// pointers
//
#include <iostream>
using namespace std;


int main() {
  // Put your code here.
  return 0;
}
